const mongoose = require("mongoose");

const Schema= mongoose.Schema

const Transaction = new Schema({
    StudentID:{
        type:String,
        required:[true,"StudentID is required"],
        // unique:true
    },
    Ref:{
        type:String
    },
    Amount:{
        type:Number
    },
    SchoolID:{
        type:String,
        required:[true,"SchoolID is required"],
    },
})

module.exports= mongoose.model("Transaction", Transaction)