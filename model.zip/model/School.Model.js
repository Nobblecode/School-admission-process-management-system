const mongoose = require("mongoose");

const Schema= mongoose.Schema

const School = new Schema({
    Name:{
        type:String,
        required:[true,"Name of school is required"],
        maxlength:[30,"Name is too Long"],
        minlength:[3,"Name is too short"],
        unique:true,
    },
    Address:{
        type:String,
        required:[true,"Address is required"],
        maxlength:[200,"Address is too Long"],
        minlength:[8,"Address is too short"]
    },
    Type:{
        type:String,
        required:[true,"Type is required"],
        enum:['University','College'],
    },
    Email:{
        type:String,
        required:[true,"Email is required"],
        maxlength:[50,"Email is too Long"],
        minlength:[5,"Email is too short"], 
        match:[/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/ , "Email is invalid"],
        unique:true
    },
    Password:{
        type:String,
        required:[true,"Password is must contain each A-Z,a-z,0-9,$#%_..."],
    },
    Verified:{
        type:Boolean,
        default:false,
    },
    Payed:{
        type:Boolean,
        default:false,
    },
    Visible:{
        type:Boolean,
        default:true,
    },
    LogoImg:{
        
            type:String,
            required:[true,"Logo is required"],
    },
    IDFormat:{
        type:String,
        required:[true,"IDFormat is required"],
        maxlength:[20,"IDFormat is too Long"],
        minlength:[2,"IDFormat is too short"]
    },
    AcceptanceFee:{
        type:Number,
        default:10000
    },
    Wallet:{
        type:Number,
        default:0
    }
})

module.exports= mongoose.model("School", School)