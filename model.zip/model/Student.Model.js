const mongoose = require("mongoose");

const Schema= mongoose.Schema

const Student = new Schema({
    SchoolID:{
        type:String,
        required:[true,"SchoolID is required"],
 
    },

    // basic details 
    FullName:{
        type:String,
        required:[true,"FullName is required"],
        maxlength:[30,"FullName is too Long"],
        minlength:[3,"FullName is too short"],
        match:[/^[A-Za-z\- ]+$/, "Fullname is invalid"]
    },
    Address:{
        type:String,
        required:[true,"Address is required"],
        maxlength:[200,"Address is too Long"],
        minlength:[8,"Address is too short"]
    },
    StateAddress:{
        type:String,
        required:[true,"State is required"],
    },
    StateOfOrigin:{
        type:String,
        required:[true,"State is required"],
    },
    PhoneNo:{
        type:String,
        required:[true,"Phone is required"],
        maxlength:[11,"phone number too long"],
        minlength:[11,"phone number too short"],
        match:[/^0[789][01]\d{8}$/, "Invalid Phone number"]
    },
    DOB:{
        type:String,
        required:[true,"Date of birth is required is required"],
       
    },
    Email:{
        type:String,
        required:[true,"Email is required"],
        maxlength:[50,"Email is too Long"],
        minlength:[5,"Email is too short"], 
        match:[/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/ , "Email is invalid"],
        unique:true
    },
    Password:{
        type:String,
        required:[true,"Password is must contain each A-Z,a-z,0-9,$#%_..."],
    },
    ProfileImage:{
        type:String,
        required:[true,"ProfileImage is required"],
    },
    NinImage:{
        type:String,
        required:[true,"ProfileImage is required"],
    },
    SchoolResult:{
        type:String,
        required:[true,"SchoolResult is required"],
    },
    
    //Other contact detail
    ParentFullName:{
        type:String,
        required:[true,"Parent/Guardian FullName is required"],
        maxlength:[40,"Parent/Guardian FullName is too Long"],
        minlength:[3,"Parent/Guardian FullName is too short"],
        match:[/^[A-Za-z\- ]+$/, "Parent/Guardian Fullname is invalid"]
    },
    ParentOccupation:{
        type:String,
        required:[true,"Parent/Guardian Occupation is required"],
        maxlength:[30,"Parent/Guardian Occupation is too Long"],
        minlength:[3,"Parent/Guardian Occupation is too short"],
    },
    ParentPhone:{
        type:String,
        required:[true,"Parent/Guardian PhoneNumber is required"],
        maxlength:[11,"Parent/Guardian phone number too long"],
        minlength:[11,"Parent/Guardian phone number too short"],
        match:[/^0[789][01]\d{8}$/, "Invalid Guargian Phone Number"]
    },

    //emergency contact
    EmergencyContactName:{
        type:String,
        required:[true,"Emergency Contact Name is required"],
        maxlength:[30,"Emergency Contact Name is too Long"],
        minlength:[3,"Emergency Contact Name is too short"],
        match:[/^[A-Za-z\- ]+$/, "Parent/Guardian Fullname is invalid"]
    },
    RelationshipToStudent:{
        type:String,
        required:[true,"Relationship to person is required"],
        maxlength:[30,"Relationship to person is too Long"],
        minlength:[3,"Relationship to person is too short"],
    },
    EmergencyPhone:{
        type:String,
        required:[true,"Emergency phone Number is required"],
        maxlength:[11,"Emergency phone number too long"],
        match:[/^0[789][01]\d{8}$/, "Invalid Emergency Phone Number"]
    },
    AlternatePhone:{
        type:String,
        maxlength:[11,"Alternate phone number too long"],
        match:[/^0[789][01]\d{8}$/, "Invalid Alternate Phone Number"]
    },

    //server provided
    Approved:{
        type:Boolean,
        default:false,
    },
    Payed:{
        type:Boolean,
        default:false,
    },
    
    StudentSchoolID:{
        type: Number,
    },
    
})




module.exports= mongoose.model("Student", Student)