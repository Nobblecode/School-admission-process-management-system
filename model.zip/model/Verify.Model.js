const mongoose = require("mongoose");

const Schema= mongoose.Schema

const Verify = new Schema({
    UserID:{
        type:String,
        required:[true,"StudentID is required"],
        unique:true
    },
    OTP:{
        type:String
    },
    Link:{
        type:String
    },
    expireAt: {
        type: Date,
        expires: "10m", default: Date.now
    },
},{timestamps:true})

module.exports= mongoose.model("Verify", Verify)