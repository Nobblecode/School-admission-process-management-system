
function Errordisplay(error) {
    console.log(error);// can be removed
        if (error.message) {
            const msg=(error.message.split(':')[2])
            return {msg:msg?(msg.split(',')[0])?(msg.split(',')[0].split(' ').find(i=>i=='dup'))?'Details already exist':(msg.split(',')[0]):'Error occured':'Issue occured from your end'}
        } else {
            console.log(error);
            return{msg:'Severe error occured'}

        }  

}


module.exports= {Errordisplay}