const router= require('express').Router()

router.use('/',require('./School/Home'))//Home page

router.use('/register',require('./School/Register'))//Register

router.use('/login',require('./School/Login'))//Login

router.use('/v',require('./School/Verify'))//verify

router.use('/payment',require('./School/Payment'))//Payment

router.use('/forget',require('./School/Forget'))//Forget

module.exports= router