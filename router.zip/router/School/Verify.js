const SchoolModel = require('../../model/School.Model')
const StudentModel = require('../../model/Student.Model')
const VerifyModel = require('../../model/Verify.Model')
const { Errordisplay } = require('../../utils/Auth.utils')

const { Sendmail } = require('../../utils/mailer.utils')

const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {
        let {email,link}= req.query

        // validating url query 
        let User= email?await SchoolModel.findOne({Email:email, Verified:false}):null

        let checkLink= User?link?await VerifyModel.findOne({UserID:User._id, Link:link}):null:null
        
        if (checkLink) {

            //verify school
            await SchoolModel.updateOne({Email:email},{Verified:true})

            
            //Emailing user
            await VerifyModel.deleteOne({UserID:User._id})

            let html=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Account Successfully Verified</title>
                <style>
                    body {
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background-color: #f8f8f8;
                        margin: 0;
                        padding: 0;
                    }
                    .container {
                        max-width: 600px;
                        margin: 0 auto;
                        padding: 20px;
                    }
                    .header {
                        text-align: center;
                        margin-bottom: 30px;
                    }
                    .logo {
                        width: 100px;
                        height: auto;
                    }
                    .content {
                        background-color: #ffffff;
                        border-radius: 10px;
                        padding: 30px;
                        box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
                    }
                    .title {
                        font-size: 24px;
                        color: #28a745;
                        margin-bottom: 20px;
                    }
                    .message {
                        font-size: 16px;
                        color: #333333;
                        margin-bottom: 20px;
                    }
                    .footer {
                        text-align: center;
                        margin-top: 30px;
                        color: #777777;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                   
                    <div class="content">
                        <h1 class="title">Account Successfully Verified</h1>
                        <p class="message">Hello ${User.Name},</p>
                        <p class="message">Congratulations! Your account has been successfully verified on our student-school matching platform.</p>
                        <p class="message">You can now fully access and enjoy all the features and benefits of our platform.</p>
                    </div>
                    <div class="footer">
                        <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
            `

            await Sendmail(email, "Account Verified Successfully",html, User.Name)  
            
            return res.send(html)
        }


        
        return res.status(404).render('404')

    } catch (error) {
        res.status(500).render('500',{msg:Errordisplay(error).msg})
    }
})

router.get('/:part',async(req,res)=>{
    try {
        let {email,School}= req.query
        let Part = req.params.part

        // validating url query 
        let User= email?await StudentModel.findOne({Email:email, Approved:false}):null

        let school = User?req.session.Id?req.session.Id.length==24?await SchoolModel.findOne({_id:`${req.session.Id}`}):null:null:null

        if (school) {
            Part=="approvededd"?await StudentModel.updateOne({Email:email},{Approved:true}):await StudentModel.deleteOne({Email:email})

            let html=Part=="approvededd"?`
            <!DOCTYPE html>
            <html lang="en">
           
            <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    
                    <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
                        <h1 style="font-size: 24px; color: #28a745; margin-bottom: 20px;">Application Approved - Payment Required</h1>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Hello ${User.FullName},</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Congratulations! Your application to ${school.Name} has been approved.</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">In order to secure your spot, please proceed to make the required fees payment.</p>
                        <div style="text-align: center; margin-top: 20px;">
                            <a href="${process.env.Link}/login" style="display: inline-block; padding: 10px 20px; background-color: #28a745; color: #ffffff; border-radius: 5px; font-size: 18px; text-decoration: none;">Pay Fees</a>
                        </div>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">We look forward to having you as a part of our institution.</p>
                    </div>
                    <div style="text-align: center; margin-top: 30px; color: #777777;">
                        <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
            
            `:`
            <!DOCTYPE html>
<html lang="en">
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #dc3545; margin-bottom: 20px;">Request Declined</h1>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Hello ${User.FullName},</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">We regret to inform you that your request has been declined by ${school.Name}.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">If you have any questions or need further clarification, please feel free to contact us.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">We appreciate your interest and hope to serve you in the future.</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

            `

            await Sendmail(email,Part=="approvededd"?`Welcome to ${school.Name}`:"Your Application has been Declined" ,html, User.Name)  
            
            return res.send(Part=="approvededd"?`
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Request Approved</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #28a745; margin-bottom: 20px;">Student Request Approved</h1>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Hello ${school.Name},</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">We are pleased to inform you that the request for ${User.FullName}'s admission has been approved.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">You can proceed with further processing and communication with the student.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Thank you for your cooperation.</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

            
            `:`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Request Decline Confirmation</title>
            </head>
            <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    
                    <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
                        <h1 style="font-size: 24px; color: #dc3545; margin-bottom: 20px;">Request Decline Confirmation</h1>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Hello ${school.Name},</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">You have successfully declined the request for admission from ${User.FullName}.</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">If you have any further actions or updates related to this, please proceed accordingly.</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Thank you for your prompt response.</p>
                    </div>
                    <div style="text-align: center; margin-top: 30px; color: #777777;">
                        <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
            

            `)
        }


        
        return res.status(404).render('404')

    } catch (error) {
        res.status(500).render('500',{msg:Errordisplay(error).msg})
    }
})

module.exports= router