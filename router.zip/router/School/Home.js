const SchoolModel = require('../../model/School.Model')
const { Errordisplay } = require('../../utils/Auth.utils')
const StudentModel = require('../../model/Student.Model')
const { Sendmail } = require('../../utils/mailer.utils')
const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {
       let sess=req.session

        if (sess.Id) {

            let Details= await SchoolModel.findOne({_id:sess.Id}),
                AllStudent = await StudentModel.find({SchoolID:sess.Id}),
                AllApprovedStudent= AllStudent?.filter(i=>i.Payed==true&&i.Approved==true),
                AllOwingStudent=  AllStudent?.filter(i=>i.Payed==false&&i.Approved==true),
                AllunapprovedStudent =  AllStudent?.filter(i=>i.Payed==false&&i.Approved==false);

            return res.render('School/Home',{Details, AllApprovedStudent,AllOwingStudent,AllunapprovedStudent,ServicePrice:process.env.ServicePrice, PK:process.env.PublicKeyPaystack,Company:process.env.Company})  
        }
        return res.redirect('/school/register')
        
    } catch (error) {
        res.status(500).render('500', {msg:Errordisplay(error).msg})
    }
})

router.get('/switch',async(req,res)=>{
    try {
       let sess=req.session
        
       let checkVerification = sess.Id?await SchoolModel.findOne({_id:sess.Id, Verified:true, Payed:true}):null
        if (checkVerification) {
            await SchoolModel.updateOne({_id:sess.Id},{Visible:!checkVerification.Visible})
           
            let html=!checkVerification.Visible?`<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Action Taken on Admission Acceptance</title>
            </head>
            <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                   
                    <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
                        <h1 style="font-size: 24px; color: #007bff; margin-bottom: 20px;">Action Taken on Admission Acceptance</h1>
                        <p style="font-size: 16px; color: #333333;">Hello ${checkVerification.Name},</p>
                        <p style="font-size: 16px; color: #333333;">This is to inform you that the action to enable the admission acceptance button has been successfully taken by your school.</p>
                        <p style="font-size: 16px; color: #333333;">Students can now register for admission by clicking the button and completing the required steps.</p>
                        <p style="font-size: 16px; color: #333333;">If you have any further questions or need assistance, please feel free to contact us.</p>
                        <p style="font-size: 16px; color: #333333;">Thank you for choosing our services.</p>
                    </div>
                    <div style="text-align: center; margin-top: 30px; color: #777777;">
                        <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
            `: `
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admission Acceptance Option Disabled</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #dc3545; margin-bottom: 20px;">Admission Acceptance Option Disabled</h1>
            <p style="font-size: 16px; color: #333333;">Hello ${checkVerification.Name},</p>
            <p style="font-size: 16px; color: #333333;">This is to inform you that the admission acceptance option has been successfully switched off by your school.</p>
            <p style="font-size: 16px; color: #333333;">Students will no longer be able to register for admission using the acceptance button.</p>
            <p style="font-size: 16px; color: #333333;">If you have any further questions or need assistance, please feel free to contact us.</p>
            <p style="font-size: 16px; color: #333333;">Thank you for using our services.</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

            `

            await Sendmail(checkVerification.Email, !checkVerification.Visible?"Admission Acceptance Option Enabled":"Admission Acceptance Option Disabled" ,html, checkVerification.Name)  
            

            return res.send(html)
        }
        return res.status(404).render('404')
        
    } catch (error) {
        res.status(500).render('500', {msg:Errordisplay(error).msg})
    }
})

router.post('/editaccount',async(req,res)=>{
    try {
       let sess=req.session
    
       let collect = req.body

       let checkVerification = sess.Id?await SchoolModel.findOne({_id:sess.Id, Verified:true, Payed:true}):null
        if (checkVerification) {
            await SchoolModel.updateOne({_id:sess.Id},collect)
            
            let html =`
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Details Updated</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #007bff; margin-bottom: 20px;">Account Details Updated</h1>
            <p style="font-size: 16px; color: #333333;">Hello ${checkVerification.Name},</p>
            <p style="font-size: 16px; color: #333333;">We are writing to inform you that your account details have been successfully updated.</p>
            <p style="font-size: 16px; color: #333333;">If you made these changes, no further action is required from your end.</p>
            <p style="font-size: 16px; color: #333333;">If you did not initiate these changes, please contact us immediately for assistance.</p>
            <p style="font-size: 16px; color: #333333;">Thank you for using our services.</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
`
            
            await Sendmail(checkVerification.Email, "Account Details Updated",html, checkVerification.Name)  

            return res.json({Access:true, Error:false})
        }
        return res.status(500).json({Access:true, Error:'account not found'})
        
    } catch (error) {
        res.status(500).json({Access:true,Error:Errordisplay(error).msg})
    }
})

module.exports= router