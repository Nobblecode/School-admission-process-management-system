const { default: axios } = require('axios')
const SchoolModel = require('../../model/School.Model')
const StudentModel = require('../../model/Student.Model')
const { Errordisplay } = require('../../utils/Auth.utils')
const { Sendmail } = require('../../utils/mailer.utils')
const TransactionModel = require('../../model/Transaction.Model')
// const agenda = require('../../utils/Agender')

const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {
        //data from client

        let sess = req.session.Id
        let ref= req.query.ref

        let checkTransaction= sess?ref?await TransactionModel.findOne({Ref:ref})?null:true:null:null
        if (checkTransaction) {
            //getting necessary data from db
            let school = await SchoolModel.findOne({_id:sess})

            let Apirequest= await axios({
                url:`https://api.paystack.co/transaction/verify/${ref}`,
                method:'GET',
                headers:{
                    Authorization:`Bearer ${process.env.SecretKeyPaystack}`,
                    Accept:'application/json'
                }
            })

            let data= await Apirequest?.data

            let validate= data?.status==true?data.data.status=="success"?(data.data.amount/100)==process.env.ServicePrice?true:null:null:null

            validate?await TransactionModel.create({StudentID:school._id,Ref:ref,Amount:(parseInt(data.data.amount)/100),SchoolID:sess}):null
            validate?await SchoolModel.updateOne({_id:school._id},{Payed:true}):null

            let htmlSchool = validate?`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Account Verification Success</title>
            </head>
            <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                    
                    <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
                        <h1 style="font-size: 24px; color: #28a745; margin-bottom: 20px;">Account Verification Success</h1>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Hello ${school.Name},</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Congratulations! Your account has been successfully verified.</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">You can now access and manage your account on our platform.</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">If you have any further questions or need assistance, please feel free to reach out to us.</p>
                        <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Thank you for choosing our services.</p>
                    </div>
                    <div style="text-align: center; margin-top: 30px; color: #777777;">
                        <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
                 `:null

            validate?await Sendmail(school.Email, "Account Verification Success",htmlSchool, school.Name):null

            return validate?res.json({Access:true, Sent:true}):res.status(500).json({Access:true,Error:data?.status==true?data.data.status=="success"?(data.data.amount/100)==school.AcceptanceFee?true:"Money didnt match":"Transaction Invalid":"Error Occured"})

        }
        res.status(500).json({Access:true,Error:`Please login again and click link <a href="${process.env.Link}/paymen?ref=${ref}">Here</a>`})
    } catch (error) {
        res.status(500).json({Access:true,Error: Errordisplay(error).msg })
    }
    
})

router.get('/withdraw',async(req,res)=>{
    try {
        //data from client

        let sess = req.session.Id

        if (sess) {
            //getting necessary data from db
            let school = await SchoolModel.findOne({_id:sess})
            school= school.Wallet>1000?school:null

            school?await SchoolModel.updateOne({_id:sess,},{Wallet:0}):null
           
            let htmlSchool = school?`
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wallet Withdrawal Success</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        
        </div>
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #28a745; margin-bottom: 20px;">Wallet Withdrawal Success</h1>
            <p style="font-size: 16px; color: #333333;">Hello ${school.Name},</p>
            <p style="font-size: 16px; color: #333333;">We are pleased to inform you that the requested wallet withdrawal has been successfully processed.</p>
            <p style="font-size: 16px; color: #333333;">The amount of NGN${school.Wallet} has been transferred to your designated account.</p>
            <p style="font-size: 16px; color: #333333;">If you have any further questions or need assistance, please feel free to reach out to us.</p>
            <p style="font-size: 16px; color: #333333;">Thank you for choosing our services.</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

                 `:null

            school?await Sendmail(school.Email, "Wallet Withdrawal Success",htmlSchool, school.Name):null

            return school?res.redirect('/school'):res.status(500).render('500',{msg:"Not enough Balance."})

        }
        res.status(404).render('404')
    } catch (error) {
        res.status(500).render('500',{msg:Errordisplay(error).msg})
    }
    
})

module.exports= router