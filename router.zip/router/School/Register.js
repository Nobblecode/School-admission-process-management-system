const SchoolModel = require('../../model/School.Model')
const VerifyModel = require('../../model/Verify.Model')
const { Errordisplay } = require('../../utils/Auth.utils')
const bcrypt = require('bcrypt')
const { OTP, Links } = require('../../utils/random.utils')
const { Sendmail } = require('../../utils/mailer.utils')
const { uploadimg } = require('../../utils/coudinary.utils')
const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {

    res.render('School/Register')
        
    } catch (error) {
        res.status(500).render('500', {msg:Errordisplay(error).msg})
    }
})

router.post('/',async(req,res)=>{
    try {
        let collect= req.body
        
        let files=req.files

        collect.Password=collect.Password?/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/.test(collect.Password)?bcrypt.hashSync(collect.Password,5):null:null

        let uploadProfile=files?.LogoImg?await uploadimg(files?.LogoImg,'/NobbleSchool/School/Profile'):null

        collect.LogoImg=uploadProfile?.url

        let newSchool = await SchoolModel.create(collect)

        let newVerif = newSchool? await VerifyModel.create({UserID:newSchool._id,OTP:OTP(), Link:Links()}):null
        
        let html=newVerif? `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Email Verification</title>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f8f8f8;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    text-align: center;
                    margin-bottom: 30px;
                }
                .logo {
                    width: 100px;
                    height: auto;
                }
                .content {
                    background-color: #ffffff;
                    border-radius: 10px;
                    padding: 30px;
                    box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
                }
                .title {
                    font-size: 24px;
                    color: #4a90e2;
                    margin-bottom: 20px;
                }
                .message {
                    font-size: 16px;
                    color: #333333;
                    margin-bottom: 20px;
                }
                .btn-container {
                    text-align: center;
                }
                .btn {
                    display: inline-block;
                    padding: 10px 20px;
                    background-color: #4a90e2;
                    color: #ffffff;
                    text-decoration: none;
                    border-radius: 5px;
                    font-size: 18px;
                }
                .footer {
                    text-align: center;
                    margin-top: 30px;
                    color: #777777;
                }
            </style>
        </head>
        <body>
            <div class="container">
                
                <div class="content">
                    <h1 class="title">Email Verification</h1>
                    <p class="message">Hello ${collect.Name},</p>
                    <p class="message">Thank you for joining our Nobble-school Registration platform!</p>
                    <p class="message">To complete your registration, please click the button below to verify your email address:</p>
                    <div class="btn-container">
                        <a href="${process.env.Link}/school/v?email=${collect.Email}&link=${newVerif.Link}" class="btn">Verify Email</a>
                    </div>
                    <p class="message">If you did not create an account on our platform, you can safely ignore this email.</p>
                </div>
                <div class="footer">
                    <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        
        `:null

        let mail = newVerif?await Sendmail(collect.Email, "Verify your Email",html, collect.Name):null

        return newVerif?res.json({Access:true, Error:false, Sent:mail?.sent}):res.status(500).json({Access:true, Error:"Unable to create account"})

    } catch (error) {
        res.status(500).json({Access:true,Error:Errordisplay(error).msg})
    }
})

module.exports= router