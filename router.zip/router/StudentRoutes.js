const router= require('express').Router()

router.use('/',require('./Student/Home'))//HOme

router.use('/register',require('./Student/Register'))//register

router.use('/login',require('./Student/Login'))//Login

router.use('/payment',require('./Student/Payment'))//Payment

router.use('/forget',require('./Student/Forget'))//Payment


module.exports= router