const SchoolModel = require('../../model/School.Model')
const StudentModel = require('../../model/Student.Model')
const VerifyModel = require('../../model/Verify.Model')
const { Errordisplay } = require('../../utils/Auth.utils')
const { Sendmail } = require('../../utils/mailer.utils')
const { OTP, Links } = require('../../utils/random.utils')
const bcrypt = require('bcrypt')
const router= require('express').Router()

router.post('/',async(req,res)=>{
    try {
        let {Email}= req.body

        // validating url query 
        let User= Email?await StudentModel.findOne({Email:Email}):null
        
        if (User) {
            let school= await SchoolModel.findOne({_id:User.SchoolID})
            //verify school
            let newVerification= await VerifyModel.create({UserID:User._id,OTP:OTP(),Link:Links()})

            let html=`
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your OTP Code</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
    
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #007bff; margin-bottom: 20px;">Your OTP Code</h1>
            <p style="font-size: 16px; color: #333333;">Hello ${User.FullName},</p>
            <p style="font-size: 16px; color: #333333;">Your One-Time Password (OTP) code is: <strong>${newVerification.OTP}</strong></p>
            <p style="font-size: 16px; color: #333333;">This code is valid for a short period of time for security reasons. Do not share your OTP with anyone.</p>
            <p style="font-size: 16px; color: #333333;">If you did not request this OTP, please ignore this message.</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

            `

            await Sendmail(Email, "Password Reset OTP",html, school.Name)  
            
            return res.status(500).json({Access:true,Error:"Go check your Email for otp"})
        }
        
        return res.status(500).json({Access:true, Error:"Email not found"})

    } catch (error) {
        res.status(500).json({Access:true,Error:Errordisplay(error).msg})
    }
})

router.post('/2',async(req,res)=>{
    try {
        let {Email,OTP,Password}= req.body

        // validating url query 
        let User= Email?await StudentModel.findOne({Email:Email}):null
        let CheckOTP= User?OTP?await VerifyModel.findOne({UserID:User._id,OTP}):null:null
        
        if (CheckOTP) {
            let school= await SchoolModel.findOne({_id:User.SchoolID})

            let newPassword=Password?/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/.test(Password)?bcrypt.hashSync(Password,5):null:null

            await StudentModel.updateOne({Email},{Password:newPassword})

            await VerifyModel.deleteOne({UserID:User._id})

            let html=`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Password Reset Success</title>
            </head>
            <body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
                <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
                  
                    <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
                        <h1 style="font-size: 24px; color: #28a745; margin-bottom: 20px;">Password Reset Success</h1>
                        <p style="font-size: 16px; color: #333333;">Hello ${User.FullName},</p>
                        <p style="font-size: 16px; color: #333333;">We are writing to inform you that your password has been successfully reset.</p>
                        <p style="font-size: 16px; color: #333333;">You can now log in to your account using your new password.</p>
                        <p style="font-size: 16px; color: #333333;">If you did not initiate this password reset, please contact us immediately for assistance.</p>
                        <p style="font-size: 16px; color: #333333;">Thank you for choosing our services.</p>
                    </div>
                    <div style="text-align: center; margin-top: 30px; color: #777777;">
                        <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
            
            `

            await Sendmail(Email, "Password Reset Successfully",html, school.Name)  
            
            return res.json({Access:true,Error:"Go check your Email for otp"})
        }
        
        return res.status(500).json({Access:true, Error:User?"Incorrect OTP":"Email not found"})

    } catch (error) {
        res.status(500).json({Access:true,Error:Errordisplay(error).msg})
    }
})

module.exports= router