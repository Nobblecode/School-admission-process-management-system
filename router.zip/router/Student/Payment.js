const { default: axios } = require('axios')
const SchoolModel = require('../../model/School.Model')
const StudentModel = require('../../model/Student.Model')
const { Errordisplay } = require('../../utils/Auth.utils')
const { Sendmail } = require('../../utils/mailer.utils')
const TransactionModel = require('../../model/Transaction.Model')

const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {
        //data from client

        let sess = req.session.Ids
        let ref= req.query.ref

        let checkTransaction= sess?ref?await TransactionModel.findOne({Ref:ref})?null:true:null:null
        if (checkTransaction) {
            //getting necessary data from db
            let User= await StudentModel.findOne({_id:sess})
            let school = await SchoolModel.findOne({_id:User.SchoolID})

            let Apirequest= await axios({
                url:`https://api.paystack.co/transaction/verify/${ref}`,
                method:'GET',
                headers:{
                    Authorization:`Bearer ${process.env.SecretKeyPaystack}`,
                    Accept:'application/json'
                }
            })

            let data= await Apirequest?.data

            let validate= data?.status==true?data.data.status=="success"?(data.data.amount/100)==school.AcceptanceFee?true:null:null:null

            validate?await TransactionModel.create({StudentID:User._id,Ref:ref,Amount:(parseInt(data.data.amount)/100),SchoolID:school._id}):null
            validate?await SchoolModel.updateOne({_id:school._id},{Wallet:(parseInt(`${school.Wallet}`))+(data.data.amount/100)}):null

            validate?await StudentModel.updateOne({_id:sess},{Payed:true}):null

            let html = validate?`
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Acceptance Fee Payment Confirmation</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
        
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #28a745; margin-bottom: 20px;">Acceptance Fee Payment Confirmation</h1>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Hello ${User.FullName},</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Congratulations! Your payment of the acceptance fee has been successfully received.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">You are now officially accepted as a student at ${school.Name}.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">If you have any further questions or need assistance, please feel free to reach out to us.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">We look forward to welcoming you to our institution!</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

            `:null

            let htmlSchool = validate?`
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Acceptance Fee Payment Notification</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; margin: 0; padding: 0;">
    <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
       
        <div style="background-color: #ffffff; border-radius: 10px; padding: 30px; box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="font-size: 24px; color: #007bff; margin-bottom: 20px;">Acceptance Fee Payment Notification</h1>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Hello ${school.Name},</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">This is to inform you that ${User.FullName} has successfully paid the acceptance fee.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">Please proceed with the necessary steps to formalize their admission process.</p>
            <p style="font-size: 16px; color: #333333; margin-bottom: 20px;">If you have any further questions or updates, feel free to take appropriate action.</p>
        </div>
        <div style="text-align: center; margin-top: 30px; color: #777777;">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
            `:null

            validate?await Sendmail(school.Email, "Acceptance Fee Payment Notification",htmlSchool, school.Name):null
            validate?await Sendmail(User.Email, "Acceptance Fee Payment Confirmation",html, school.Name):null

            return validate?res.json({Access:true, Sent:true}):res.status(500).json({Access:true,Error:data?.status==true?data.data.status=="success"?(data.data.amount/100)==school.AcceptanceFee?true:"Money didnt match":"Transaction Invalid":"Error Occured"})

        }
        res.status(500).json({Access:true,Error:`Please login again and click link "${process.env.Link}/paymen?ref=${ref}" else your transaction will be held`})
    } catch (error) {
        res.status(500).json({Access:true,Error: Errordisplay(error).msg })
    }
    
})



module.exports= router