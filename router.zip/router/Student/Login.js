
const { Errordisplay } = require('../../utils/Auth.utils')
const bcrypt = require('bcrypt')

const StudentModel = require('../../model/Student.Model')
const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {
       
    res.render('Student/Login')
        
    } catch (error) {
        res.status(500).render('500', {msg:Errordisplay(error).msg})
    }
})

router.post('/',async(req,res)=>{
    try {
        let {Email,Password}= req.body

        // validating inputs 
        let User= Email?await StudentModel.findOne({Email}):null

        let CheckPassword= User?bcrypt.compareSync(Password,User.Password):null

        if (CheckPassword) {
            
            //saving verified user to session
            User.Approved==true?req.session.Ids=User._id:null
            User.Approved==true?req.session.Email=User.Email:null           
  
            return User.Approved==true?res.json({Access:true, Error:false, }):res.status(500).json({Access:true,Error:"Admission request is still processing, please have patience.",})
        }


        
        return res.status(500).json({Access:true, Error:User?"Password Is invalid":"User doesnt exist."})

    } catch (error) {
        res.status(500).json({Access:true,Error:Errordisplay(error).msg})
    }
})

module.exports= router