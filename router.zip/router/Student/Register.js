const SchoolModel = require('../../model/School.Model')
const StudentModel = require('../../model/Student.Model')
const { Errordisplay } = require('../../utils/Auth.utils')
const { uploadimg } = require('../../utils/coudinary.utils')
const { Sendmail } = require('../../utils/mailer.utils')
const bcrypt= require('bcrypt')
const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {
        let allSchool = await SchoolModel.find({Visible:true, Verified:true,Payed:true})
    res.render('Student/Register',{allSchool})
        
    } catch (error) {
        res.status(500).render('500', {msg:Errordisplay(error).msg})
    }
})

router.post('/',async(req,res)=>{
    try {
        let collect= req.body
        
        let files=req.files

        collect.Password=collect.Password?/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/.test(collect.Password)?bcrypt.hashSync(collect.Password,5):null:null
        
        let GetSchool = collect.SchoolID?collect.SchoolID.length==24?await SchoolModel.findOne({_id:collect.SchoolID, Visible:true, Verified:true,Payed:true}):null:null

        let uploadProfile=GetSchool?files?.ProfileImage?await uploadimg(files?.ProfileImage,'/NobbleSchool/Student/Profile'):null:null

        let NinImageupload=GetSchool? files?.NinImage?await uploadimg(files?.NinImage,'/NobbleSchool/Student/Nin'):null:null

        let ResultSchool=GetSchool?files?.SchoolResult?await uploadimg(files?.SchoolResult,'/NobbleSchool/Student/Result'):null:null

        collect.ProfileImage=uploadProfile?.url
        collect.NinImage=NinImageupload?.url
        collect.SchoolResult=ResultSchool?.url
        const maxStudentIdDoc = await StudentModel.findOne().sort({ StudentSchoolID: -1 });
        collect.StudentSchoolID = maxStudentIdDoc ? maxStudentIdDoc.StudentSchoolID + 1 : 1;
      


        let newStudent = GetSchool? await StudentModel.create(collect):null

        let html=GetSchool? `
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admission Preview Notification</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo {
            width: 100px;
            height: auto;
        }
        .content {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
        }
        .title {
            font-size: 24px;
            color: #ffc107;
            margin-bottom: 20px;
        }
        .message {
            font-size: 16px;
            color: #333333;
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #777777;
        }
    </style>
</head>
<body>
    <div class="container">
       
        <div class="content">
            <h1 class="title">Admission Preview Notification</h1>
            <p class="message">Hello ${newStudent.FullName},</p>
            <p class="message">Thank you for submitting your admission application to ${GetSchool.Name}.</p>
            <p class="message">Your application is currently being reviewed. An email will be sent to you once the preview process is complete.</p>
            <p class="message">We appreciate your interest in joining our institution and look forward to connecting with you soon.</p>
        </div>
        <div class="footer">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

        `:null

        
        let htmlSchool=GetSchool?`
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admission Application Preview</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f8f8;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo {
            width: 100px;
            height: auto;
        }
        .content {
            background-color: #ffffff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
        }
        .title {
            font-size: 24px;
            color: #007bff;
            margin-bottom: 20px;
        }
        .message {
            font-size: 16px;
            color: #333333;
            margin-bottom: 20px;
        }
        .btn-container {
            text-align: center;
            margin-top: 20px;
        }
        .accept-btn, .reject-btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 18px;
            text-decoration: none;
        }
        .accept-btn {
            background-color: #28a745;
            color: #ffffff;
            margin-right: 10px;
        }
        .reject-btn {
            background-color: #dc3545;
            color: #ffffff;
        }
        .profile-info {
            margin-top: 30px;
            padding: 20px;
            background-color: #f5f5f5;
            border-radius: 10px;
        }
        .profile-image {
            max-width: 100px;
            height: auto;
            border-radius: 5%;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #777777;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <div class="content">
            <h1 class="title">Admission Application Preview</h1>
            <p class="message">Hello ${GetSchool.Name},</p>
            <p class="message">You have an admission application pending for review from ${collect.FullName}.</p>
            <p class="message">Make sure you are onthe system and browser you lgged in with.</p>
            <div class="btn-container">
                <a href="${process.env.Link}/student/v/approvededd?email=${collect.Email}&School=${collect.SchoolID}" class="accept-btn">Accept</a>
                <a href="${process.env.Link}/student/v/declinedddd?email=${collect.Email}&School=${collect.SchoolID}"class="reject-btn">Reject</a>
            </div>
            <div class="profile-info">
                <h2>Student Profile:</h2>
                <p><strong>Name:</strong> ${collect.FullName}</p>
                <p><strong>Email:</strong> ${collect.Email}</p>
                <p><strong>Date of Birth:</strong> ${collect.DOB}</p>
                <h3>Uploaded Image:</h3>
                <img src="${newStudent.ProfileImage}" alt="Profile Image" class="profile-image">
                <img src="${newStudent.NinImage}" alt="Profile Image" class="profile-image">
                <img src="${newStudent.SchoolResult}" alt="Profile Image" class="profile-image">
            
                </div>
        </div>
        <div class="footer">
            <p>&copy; 2023 ${process.env.Company}. All rights reserved.</p>
        </div>
    </div>
</body>
</html>

        `:null

        let mail = GetSchool?await Sendmail(collect.Email, "Admission Preview Notification",html, GetSchool.Name):null
        GetSchool?await Sendmail(GetSchool.Email, "Admission Request",htmlSchool, GetSchool.Name):null

        return GetSchool?res.json({Access:true, Error:false, Sent:mail?.sent, Msg:html}):res.status(500).json({Access:true, Error:"School not found"})

    } catch (error) {
        res.status(500).json({Access:true,Error:Errordisplay(error).msg})
    }
})

module.exports= router