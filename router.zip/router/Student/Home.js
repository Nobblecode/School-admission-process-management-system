const SchoolModel = require('../../model/School.Model')
const StudentModel = require('../../model/Student.Model')
const { Errordisplay } = require('../../utils/Auth.utils')

const router= require('express').Router()

router.get('/',async(req,res)=>{
    try {
        let sess = req.session.Ids
        if (sess) {
            let User= await StudentModel.findOne({_id:sess})
            let school = await SchoolModel.findOne({_id:User.SchoolID})

            return User.Payed==true?res.render("Student/Dashboard",{User,school, Company:process.env.Company}):res.render('Student/Payment',{Price:school.AcceptanceFee, PK:process.env.PublicKeyPaystack, User,school})
        }
        res.redirect('/login')
    } catch (error) {
        res.render('500',{msg: Errordisplay(error).msg })
    }
    
})



module.exports= router